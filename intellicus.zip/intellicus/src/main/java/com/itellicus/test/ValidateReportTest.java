package com.itellicus.test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.intelicus.util.TestInitialization;
import com.intelicus.util.TestUtil;
import com.itellicus.pages.AdHocReportPage;
import com.itellicus.pages.DemoLogIn;
import com.itellicus.pages.HomeScreen;
import com.itellicus.pages.NavigatePage;

/**
 * @author jeevan.nikam
 * Verifying & validating Intellicus login & report generation functionality
 */
public class ValidateReportTest extends TestInitialization {

	
	/**
	 * @return
	 * Pass userName and password using data provider
	 */
	@DataProvider(name = "Login")
	public static Object[][] provideData(){
			String userName = TestInitialization.getUpdatedProptiesFile().getProperty("userName");
			String password = TestInitialization.getUpdatedProptiesFile().getProperty("password");
		 return new Object[][] { { userName, password }};
	}
	
	
	/**
	 * @param userName
	 * @param password
	 * @throws InterruptedException
	 * Log In into the application
	 */
	@Test(dataProvider = "Login")
	public void logInWithValidCredentials(String userName,String password) throws InterruptedException {

		DemoLogIn logIn = new DemoLogIn(driver);
		NavigatePage nav = new NavigatePage(driver);
		logIn.goToLogInFrame();
		logIn.login(userName, password);
		Assert.assertTrue(TestUtil.isDisplayed(nav.navigateBar, 10));
	}

	/**
	 * @throws InterruptedException
	 * Validate report name with provided report name
	 */
	@Test(dependsOnMethods = { "logInWithValidCredentials" })
	public void validateReport() throws InterruptedException {
		
		Thread.sleep(10000);
		NavigatePage nav = new NavigatePage(driver);
		HomeScreen home = new HomeScreen(driver);
		AdHocReportPage report = new AdHocReportPage(driver);
		nav.clickOnNevigationPage();
		nav.goToAdHocReport();
		home.designReport(TestInitialization.getUpdatedProptiesFile().getProperty("reportTitle"));
		Assert.assertEquals(TestInitialization.getUpdatedProptiesFile().getProperty("reportTitle"), report.gettReportName());
	}
}
