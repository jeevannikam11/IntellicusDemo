package com.itellicus.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.intelicus.util.TestInitialization;
import com.intelicus.util.TestUtil;

/**
 * @author jeevan.nikam
 * Checking the functionality of Navigate bar
 *
 */
public class NavigatePage extends TestInitialization {

	static WebDriver driver;

	public NavigatePage(WebDriver driver) {
		DemoLogIn.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = NavigatorPage.navigateBar_Xpath)
	public WebElement navigateBar;

	@FindBy(how = How.XPATH, using = NavigatorPage.design_Xpath)
	public WebElement design;

	@FindBy(how = How.XPATH, using = NavigatorPage.adhocReport_Xpath)
	public WebElement adhocReport;

	/**
	 * @throws InterruptedException
	 * Method to click on navigation bar
	 */
	public void clickOnNevigationPage() throws InterruptedException {
		if (TestUtil.isDisplayed(navigateBar, 10)) {
			TestUtil.clickOnElement(navigateBar);
		} else {
			log.info("Navigation bar is not visible");
		}
	}

	/**
	 * @throws InterruptedException
	 * Method to select Adhoc report
	 */
	public void goToAdHocReport() throws InterruptedException {
	
			TestUtil.clickOnElement(design);
			TestUtil.clickOnElement(adhocReport);
		
	}

}
