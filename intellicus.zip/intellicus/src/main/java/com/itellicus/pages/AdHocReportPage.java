package com.itellicus.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.intelicus.util.TestInitialization;
import com.intelicus.util.TestUtil;

/**
 * @author jeevan.nikam
 * 
 */
public class AdHocReportPage extends TestInitialization{
	
	static WebDriver driver;

	public AdHocReportPage(WebDriver driver) {
		DemoLogIn.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.NAME, using = NavigatorPage.ReportScreen.reportFrame_Name)
	public WebElement reportFrame;

	@FindBy(how = How.NAME, using = NavigatorPage.ReportScreen.htmlViewverFrame_Name)
	public WebElement htmlViewverFrame;

	@FindBy(how = How.XPATH, using = NavigatorPage.ReportScreen.reportName_Xpath)
	public WebElement reportName;
	
	/**
	 * @return
	 * @throws InterruptedException
	 * Method get report name
	 */
	public String gettReportName() throws InterruptedException{
		TestUtil.switchFrame(reportFrame);
		TestUtil.waitForAnElementToVisible(htmlViewverFrame);
		TestUtil.switchFrame(htmlViewverFrame);
		TestUtil.waitForAnElementToVisible(reportName);
		return reportName.getAttribute("title");
	}
}
