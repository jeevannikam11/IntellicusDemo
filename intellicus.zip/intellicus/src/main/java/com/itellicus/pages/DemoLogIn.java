package com.itellicus.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.intelicus.util.TestInitialization;
import com.intelicus.util.TestUtil;

/**
 * @author jeevan.nikam
 * Verify logIn functionality
 */
public class DemoLogIn extends TestInitialization {

	static WebDriver driver;

	public DemoLogIn(WebDriver driver) {
		DemoLogIn.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = LoginScreen.userName_Xapth)
	public WebElement userName;

	@FindBy(how = How.XPATH, using = LoginScreen.password_Xpath)
	public WebElement password;

	@FindBy(how = How.XPATH, using = LoginScreen.loginButton_Xpath)
	public WebElement loginButton;
	
	@FindBy(how = How.NAME, using = LoginScreen.frame_Name)
	public WebElement frameName;
	
	/**
	 * @throws InterruptedException
	 */
	public void goToLogInFrame() throws InterruptedException{
		TestUtil.switchFrame(frameName);
	}
	
	/**
	 * @param userNameText
	 * @param passwordText
	 * @throws InterruptedException
	 */
	public void login(String userNameText, String passwordText) throws InterruptedException {

		sendKeys(userNameText, userName, "UserName field");
		sendKeys(passwordText, password, "Password field");
		TestUtil.clickOnElement(loginButton);
	}
}