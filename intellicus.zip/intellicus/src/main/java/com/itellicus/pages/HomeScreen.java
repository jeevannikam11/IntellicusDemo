package com.itellicus.pages;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.intelicus.util.TestInitialization;
import com.intelicus.util.TestUtil;

/**
 * @author jeevan.nikam
 *	Checking the functionality of the Home Page 
 */
public class HomeScreen extends TestInitialization {

	static WebDriver driver;

	public HomeScreen(WebDriver driver) {
		DemoLogIn.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.NAME, using = NavigatorPage.HomeScreen.dataSourceFrame_Name)
	public WebElement dataSourceFrame;

	@FindBy(how = How.XPATH, using = NavigatorPage.HomeScreen.queryObjectImage_Xpath)
	public WebElement queryObjectImage;

	@FindBy(how = How.XPATH, using = NavigatorPage.HomeScreen.stateSell_Xpath)
	public List<WebElement> stateSellList; 

	@FindBy(how = How.XPATH, using = NavigatorPage.HomeScreen.qqSalesData_Xpath)
	public WebElement qqSalesData;

	@FindBy(how = How.XPATH, using = NavigatorPage.HomeScreen.reportTitle_XpathList)
	public WebElement reportTitle; 

	@FindBy(how = How.XPATH, using = NavigatorPage.HomeScreen.runButton_Xpath)
	public WebElement runButton;
	
	/**
	 * @param reportName
	 * @throws InterruptedException
	 * Check the Report Generation Functionality
	 */
	public void designReport(String reportName) throws InterruptedException{
		
		TestUtil.switchFrame(dataSourceFrame);
		TestUtil.waitForAnElementToVisible(queryObjectImage);
		TestUtil.clickOnElement(queryObjectImage);
		TestUtil.clickOnElement(stateSellList.get(0));
		TestUtil.waitForAnElementToVisible(qqSalesData);
		try {
			TestUtil.doubleClick(qqSalesData);
			TestUtil.waitForAnElementToVisible(reportTitle);
		} catch (NoSuchElementException e) {
			System.out.println(e);
			driver.close();
		}
		TestUtil.clickOnElement(reportTitle);
		sendKeys(reportName, reportTitle, "Report title");
		TestUtil.clickOnElement(runButton);
	}
}
