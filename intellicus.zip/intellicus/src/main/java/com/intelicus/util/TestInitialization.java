package com.intelicus.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.intellicus.config.ObjectRepository;

/**
 * @author jeevan.nikam
 *	Common class to initialize test suite
 */
public class TestInitialization extends ObjectRepository{
	
	public static WebDriver driver;
	public static Logger log;
	public static WebDriverWait wait = null;
	
	protected static String configFilePath1 = System.getProperty("user.dir") + File.separator+ "src" + File.separator
			+ "main" + File.separator + "java" + File.separator + "com" + File.separator + "intellicus" + File.separator
			+ "config" + File.separator + "config.properties";
	
	
	
	/**
	 * @throws IOException
	 * @throws InterruptedException
	 * Launch web driver
	 */
	@BeforeSuite
	public void launchWebDriver() throws IOException, InterruptedException{
		String url = getUpdatedProptiesFile().getProperty("URL");
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + File.separator + "chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 60L);
	}
	
	/**
	 * @param text
	 * @param we
	 * @param objectName
	 * @throws InterruptedException
	 * Pass input from keyboard
	 */
	public static void sendKeys(String text, WebElement we, String objectName) throws InterruptedException {

		we.sendKeys(Keys.CONTROL, "a");
		we.sendKeys(Keys.DELETE);
		we.sendKeys(text);
	}
	
	
	/**
	 * @return
	 * Read updated property file
	 */
	public static Properties getUpdatedProptiesFile() {
		Properties PR = new Properties();
		FileInputStream FI;
		try {
			System.out.println(configFilePath1);
			//configFilePath = "D:\\Jeevan\\MyWork\\intellicus\\src\\main\\java\\com\\intellicus\\config\\config.properties";
			FI = new FileInputStream(configFilePath1);
			PR.load(FI);
		} catch (IOException e) {

			e.printStackTrace();
		}

		return PR;
	}
	
	/**
	 * After suite close driver
	 */
	@AfterSuite
	public void driverClose()
	{
		driver.close();
	}

}
