package com.intelicus.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author jeevan.nikam
 * Common class to write all the re-usable methods used in the framework
 */
public class TestUtil extends TestInitialization {

	/**
	 * @param we
	 * @param waitingTimeInSec
	 * @return
	 * Check element is visible
	 */
	public static boolean isDisplayed(WebElement we, int waitingTimeInSec) {

		boolean isVisible;
		driver.manage().timeouts().implicitlyWait(waitingTimeInSec, TimeUnit.SECONDS);
		try {
			if (we.isDisplayed()) {
				isVisible = true;
			} else {
				isVisible = false;
			}
		} catch (NoSuchElementException e) {
			isVisible = false;
		}
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		return isVisible;
	}

	/**
	 * @param we
	 * @param elementName
	 * Check element present on webpage
	 */
	public static void isElementExist(WebElement we, String elementName) {
		we.isDisplayed();
		log.info(LogStatus.PASS + elementName + " is visible ");
		log.info("Element is displayed " + elementName);
	}

	/**
	 * @param frameName
	 * @throws InterruptedException
	 * Switch frame
	 */
	public static void switchFrame(WebElement frameName) throws InterruptedException {
		try {
			driver.switchTo().frame(frameName);
			Thread.sleep(6000);
		} catch (Exception ex) {
			TestInitialization.log.info("Element not displayed on page " + ex.getMessage());
			driver.close();
		}

	}

	/**
	 * @param we
	 * @throws InterruptedException
	 * Double click on web element
	 */
	public static void doubleClick(WebElement we) throws InterruptedException {

		Actions action = new Actions(driver);
		try {
			action.doubleClick(we);
			action.build().perform();
			Thread.sleep(10000);
		} catch (Exception ex) {
			TestInitialization.log.info("Element not displayed on page " + ex.getMessage());
			driver.close();
		}
	}

	/**
	 * @param key
	 * @param we
	 * Send data from keyboard
	 */
	public static void sendKeyFromKeyboard(Keys key, WebElement we) {

		TestInitialization.log.info("Sending Key from keyboard " + key);
		we.sendKeys(key);
	}

	/**
	 * @param we
	 * Wait for element to be visible
	 */
	public static void waitForAnElementToVisible(WebElement we) {
		try {
			wait.until(ExpectedConditions.visibilityOf(we));
		} catch (Exception ex) {
			TestInitialization.log.info("Element not displayed on page " + ex.getMessage());
			driver.close();
		}
	}

	/**
	 * @param we
	 * @throws InterruptedException
	 * Click on web element
	 */
	public static void clickOnElement(WebElement we) throws InterruptedException {
		try {
			we.click();
			Thread.sleep(5000);
		} catch (Exception ex) {
			TestInitialization.log.info("Element not displayed on page " + ex.getMessage());
			driver.close();
		}
	}
}
