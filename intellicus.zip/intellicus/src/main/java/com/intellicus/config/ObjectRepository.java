package com.intellicus.config;

/**
 * @author jeevan.nikam
 * Object repository to store all web elements
 */
public class ObjectRepository {

	protected static class LoginScreen {
		/**
		 * Login page item locator
		 */
		public static final String userName_Xapth = "//*[@id='TXT_USERID']";
		public static final String password_Xpath = "//*[@id='TXT_PASSWORD']";
		public static final String loginButton_Xpath = ".//*[@id='login_btn_Div']/div[3]/input";
		public static final String frame_Name = "linkContainer";
	}

	protected static class NavigatorPage {

		/**
		 * Home page item locator
		 */
		public static final String navigateBar_Xpath = "//*[@id='toolbarNavigation']/div[1]/i[1]";
		public static final String design_Xpath = "//*[@id='toolboxItems']/div[3]/div[1]/div[2]/h6";
		public static final String adhocReport_Xpath = "//*[@id='2-1']";

		public static class HomeScreen {
			public static final String dataSourceFrame_Name = "linkContainer2";
			public static final String queryObjectImage_Xpath = "//*[@id='tableEntityName']/tbody/tr/td[3]/img";
			public static final String stateSell_Xpath = "//*[contains(@class, 'gridbox gridbox_OBS isModern')]/div[2]/table/tbody/tr[3]/td[1]/div/img[2]";
			public static final String qqSalesData_Xpath = "//span[contains(text(),'QO_SalesData')]";
			public static final String reportTitle_XpathList = "//*[@id='txtReportTitle']";
			public static final String runButton_Xpath = "//*[@id='btnRun']";
		}

		public static class ReportScreen {
			public static final String reportFrame_Name = "reportOutputIframe";
			public static final String htmlViewverFrame_Name = "frmHTMLViewer";
			public static final String reportName_Xpath = "//div[contains(@class,'cssText')]/table/tbody/tr/td";
		}

	}

}
